/* PREVENTA IA — CORE FUNCIONAL
   Shared domain/storage layer. Backwards compatible with V1.
*/
(function () {
  "use strict";

  const KEYS = Object.freeze({
    OPPS: "preventa_opportunities",
    CURRENT: "preventa_current_opportunity",
    ANALYSIS: "preventa_document_analysis",
    ACTIVITY: "preventa_activity_log",
    PROSPECTS: "preventa_prospects"
  });

  const STATUSES = Object.freeze([
    "new", "analysis", "quote", "proposal", "won", "lost"
  ]);

  function now() { return new Date().toISOString(); }
  function id(prefix) { return prefix + "_" + Date.now() + "_" + Math.random().toString(36).slice(2, 8); }
  function read(key, fallback) {
    try { const v = JSON.parse(localStorage.getItem(key) || "null"); return v == null ? fallback : v; }
    catch (_) { return fallback; }
  }
  function write(key, value) { localStorage.setItem(key, JSON.stringify(value)); return value; }

  function normalizeOpportunity(raw) {
    const o = Object.assign({}, raw || {});
    if (!o.id) o.id = id("OP");
    if (!o.createdAt) o.createdAt = now();
    o.updatedAt = o.updatedAt || o.createdAt;
    o.status = STATUSES.includes(o.status) ? o.status : "analysis";
    o.solution = o.solution || o.product || "Por definir";
    o.product = o.product || "";
    o.productFolderId = o.productFolderId || "";
    o.quote = o.quote || null;
    o.finalProposal = o.finalProposal || null;
    o.analysis = o.analysis || null;
    o.sourceDocument = o.sourceDocument || (o.analysis && o.analysis.fileName) || "";
    o.origin = o.origin || (o.analysis ? "documento" : "manual");
    o.requirements = o.requirements || "";
    o.risks = o.risks || "";
    o.activities = Array.isArray(o.activities) ? o.activities : [];
    o.history = Array.isArray(o.history) ? o.history : [];
    return o;
  }

  function getOpportunities() {
    const list = read(KEYS.OPPS, []);
    return Array.isArray(list) ? list.map(normalizeOpportunity) : [];
  }

  function saveOpportunities(list) {
    return write(KEYS.OPPS, (list || []).map(normalizeOpportunity));
  }

  function getOpportunity(idValue) {
    return getOpportunities().find(o => String(o.id) === String(idValue)) || null;
  }

  function setCurrentOpportunity(opportunity) {
    const normalized = normalizeOpportunity(opportunity);
    write(KEYS.CURRENT, normalized);
    return normalized;
  }

  function getCurrentOpportunity() {
    const current = read(KEYS.CURRENT, null);
    return current ? normalizeOpportunity(current) : null;
  }

  function addActivity(opportunity, type, detail) {
    const item = {
      id: id("ACT"),
      type: type || "update",
      detail: detail || "",
      at: now()
    };
    opportunity.activities = Array.isArray(opportunity.activities) ? opportunity.activities : [];
    opportunity.activities.unshift(item);
    opportunity.history = Array.isArray(opportunity.history) ? opportunity.history : [];
    opportunity.history.unshift(item);
    return item;
  }

  function upsertOpportunity(raw, activity) {
    const opportunity = normalizeOpportunity(raw);
    const list = getOpportunities();
    const index = list.findIndex(o => String(o.id) === String(opportunity.id));
    opportunity.updatedAt = now();
    if (activity) addActivity(opportunity, activity.type, activity.detail);
    if (index >= 0) list[index] = opportunity;
    else list.unshift(opportunity);
    saveOpportunities(list);
    setCurrentOpportunity(opportunity);
    return opportunity;
  }

  function updateOpportunity(idValue, patch, activity) {
    const list = getOpportunities();
    const index = list.findIndex(o => String(o.id) === String(idValue));
    if (index < 0) return null;
    const opportunity = Object.assign({}, list[index], patch || {});
    opportunity.updatedAt = now();
    if (activity) addActivity(opportunity, activity.type, activity.detail);
    list[index] = normalizeOpportunity(opportunity);
    saveOpportunities(list);
    setCurrentOpportunity(list[index]);
    return list[index];
  }

  function transitionOpportunity(idValue, status, detail) {
    if (!STATUSES.includes(status)) throw new Error("Estado inválido: " + status);
    const labels = {new:"Nueva", analysis:"En análisis", quote:"Cotizando", proposal:"Propuesta", won:"Ganada", lost:"Perdida"};
    return updateOpportunity(idValue, { status: status }, { type: "status", detail: detail || ("Estado → " + labels[status]) });
  }

  function createFromAnalysis(analysis, overrides) {
    const a = analysis || {};
    const o = Object.assign({
      id: id("OP"),
      client: a.client || a.cliente || "",
      project: a.project || a.proyecto || a.fileName || "Oportunidad desde análisis",
      solution: a.solution || a.recommendedSolution || "Por definir",
      status: "analysis",
      users: a.users || "",
      storage: a.storage || "",
      documents: a.documents || "",
      workflows: a.workflows || "",
      ocr: a.ocr || "",
      signatures: a.signatures || "",
      infrastructure: a.infrastructure || "",
      deadline: a.deadline || "",
      objective: a.objective || "",
      requirements: a.requirements || "",
      risks: a.risks || "",
      notes: a.notes || "",
      analysis: a,
      sourceDocument: a.fileName || "",
      origin: "documento"
    }, overrides || {});
    return upsertOpportunity(o, { type: "created", detail: "Oportunidad creada desde análisis de documento" });
  }

  function createFromMarket(payload) {
    const p = payload || {};
    const o = {
      id: id("OP"),
      client: p.client || ("Prospecto sectorial · " + (p.industry || "Sin industria")),
      project: p.project || ((p.productName || p.product || "Solución") + " · " + (p.industry || "Mercado")),
      solution: p.productName || p.product || "Por definir",
      product: p.productName || p.product || "",
      status: "new",
      users: p.employeesPotential || "",
      storage: "",
      documents: "",
      workflows: "",
      ocr: "",
      signatures: "",
      infrastructure: "",
      deadline: "",
      objective: "Prospecto generado desde Mercado 360",
      requirements: p.criteria || "Necesidad inferida a nivel sectorial; validar con relevamiento.",
      risks: "La señal de mercado no implica intención individual de compra.",
      notes: p.notes || "",
      origin: "mercado",
      market: p,
      createdAt: now()
    };
    return upsertOpportunity(o, { type: "created", detail: "Oportunidad creada desde Mercado 360" });
  }

  function attachQuote(idValue, quote) {
    return updateOpportunity(idValue, {
      quote: quote || null,
      product: (quote && quote.product) || "",
      productFolderId: (quote && quote.productFolderId) || "",
      solution: (quote && quote.product) || "Por definir",
      status: "quote"
    }, { type: "quote", detail: "Cotización guardada" });
  }

  function attachProposal(idValue, proposal) {
    return updateOpportunity(idValue, {
      finalProposal: proposal || null,
      status: "proposal"
    }, { type: "proposal", detail: "Propuesta final asociada" });
  }

  function saveAnalysis(analysis) {
    const a = Object.assign({}, analysis || {});
    a.id = a.id || id("AN");
    a.updatedAt = now();
    write(KEYS.ANALYSIS, a);
    return a;
  }

  function getAnalysis() { return read(KEYS.ANALYSIS, null); }
  function logGlobal(type, detail, entityId) {
    const list = read(KEYS.ACTIVITY, []);
    list.unshift({ id: id("LOG"), type, detail, entityId: entityId || null, at: now() });
    write(KEYS.ACTIVITY, list.slice(0, 500));
  }

  function contextText(opportunity) {
    const o = normalizeOpportunity(opportunity || getCurrentOpportunity() || {});
    return [
      "OPORTUNIDAD: " + (o.project || "Sin proyecto"),
      "CLIENTE: " + (o.client || "Sin cliente"),
      "ESTADO: " + o.status,
      "SOLUCIÓN: " + (o.solution || "Por definir"),
      "USUARIOS: " + (o.users || "No definido"),
      "STORAGE: " + (o.storage || "No definido"),
      "DOCUMENTOS: " + (o.documents || "No definido"),
      "WORKFLOWS: " + (o.workflows || "No definido"),
      "OCR: " + (o.ocr || "No definido"),
      "FIRMAS: " + (o.signatures || "No definido"),
      "INFRAESTRUCTURA: " + (o.infrastructure || "No definido"),
      "PLAZO: " + (o.deadline || "No definido"),
      "REQUERIMIENTOS: " + (o.requirements || "No definidos"),
      "RIESGOS: " + (o.risks || "No definidos"),
      "DOCUMENTO ORIGEN: " + (o.sourceDocument || "No asociado")
    ].join("\n");
  }

  window.PreventaCore = {
    keys: KEYS,
    statuses: STATUSES,
    id,
    normalizeOpportunity,
    getOpportunities,
    saveOpportunities,
    getOpportunity,
    setCurrentOpportunity,
    getCurrentOpportunity,
    upsertOpportunity,
    updateOpportunity,
    transitionOpportunity,
    createFromAnalysis,
    createFromMarket,
    attachQuote,
    attachProposal,
    saveAnalysis,
    getAnalysis,
    logGlobal,
    contextText,
    addActivity
  };
})();
