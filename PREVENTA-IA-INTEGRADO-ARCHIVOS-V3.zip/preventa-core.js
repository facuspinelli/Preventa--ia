/* PREVENTA IA - Núcleo integrado V3
   Fuente única de verdad para oportunidades, análisis, cotizaciones,
   propuestas, prospectos y actividad. Funciona sin backend ni IA paga.
*/
(function(){
  'use strict';

  const KEYS = {
    OPPS:'preventa_opportunities',
    CURRENT:'preventa_current_opportunity',
    ANALYSIS:'preventa_document_analysis',
    PROSPECTS:'preventa_prospects',
    ACTIVITY:'preventa_activity',
    DOCUMENTS:'preventa_documents',
    MARKET:'preventa_mercado_360_config',
    KNOWLEDGE:'preventa_ia_conocimiento',
    LIBRARY:'preventa_library_folders'
  };

  const STAGES = [
    {id:'new',label:'Nueva'},
    {id:'analysis',label:'En análisis'},
    {id:'quote',label:'Cotizando'},
    {id:'proposal',label:'Propuesta'},
    {id:'won',label:'Ganada'},
    {id:'lost',label:'Perdida'}
  ];

  function read(key,fallback){
    try{
      const raw = localStorage.getItem(key);
      if(raw===null) return fallback;
      const value = JSON.parse(raw);
      return value==null ? fallback : value;
    }catch(e){ return fallback; }
  }

  function write(key,value){
    localStorage.setItem(key,JSON.stringify(value));
    return value;
  }

  function uid(prefix){
    return (prefix||'id')+'_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,8);
  }

  function now(){ return new Date().toISOString(); }

  function stageId(value){
    const v = String(value||'').trim().toLowerCase();
    const map = {
      'nueva':'new','nuevo':'new','new':'new',
      'en análisis':'analysis','en analisis':'analysis','analisis':'analysis','analysis':'analysis',
      'cotizando':'quote','cotizada':'quote','quote':'quote',
      'propuesta':'proposal','proposal':'proposal',
      'ganada':'won','ganado':'won','won':'won',
      'perdida':'lost','perdida':'lost','lost':'lost'
    };
    return map[v] || 'new';
  }

  function normalize(o){
    if(!o) return null;
    const stage = stageId(o.stage || o.status);
    const analysis = o.analysis || null;
    return {
      ...o,
      id:o.id || uid('opp'),
      client:o.client || o.company || '',
      project:o.project || o.title || '',
      contact:o.contact || '',
      origin:o.origin || 'manual',
      owner:o.owner || '',
      stage,
      status:stage,
      nextAction:o.nextAction || '',
      nextActionDate:o.nextActionDate || '',
      users:o.users ?? analysis?.users ?? '',
      storage:o.storage ?? analysis?.storage ?? '',
      documents:o.documents ?? analysis?.documents ?? '',
      workflows:o.workflows ?? analysis?.workflows ?? '',
      ocr:o.ocr ?? analysis?.ocr ?? '',
      signatures:o.signatures ?? analysis?.signatures ?? '',
      infrastructure:o.infrastructure ?? analysis?.infrastructure ?? '',
      deadline:o.deadline ?? analysis?.deadline ?? '',
      objective:o.objective || '',
      requirements:o.requirements || '',
      solution:o.solution || '',
      risks:o.risks || '',
      notes:o.notes || '',
      product:o.product || '',
      productFolderId:o.productFolderId || '',
      analysis,
      quote:o.quote || null,
      finalProposal:o.finalProposal || null,
      sourceDocument:o.sourceDocument || analysis?.fileName || '',
      evidence:o.evidence || analysis?.evidence || [],
      createdAt:o.createdAt || now(),
      updatedAt:o.updatedAt || now()
    };
  }

  function getOpportunities(){
    const list = read(KEYS.OPPS,[]);
    return Array.isArray(list) ? list.map(normalize).filter(Boolean) : [];
  }

  function saveOpportunities(list){
    const normalized = (Array.isArray(list)?list:[]).map(normalize);
    write(KEYS.OPPS,normalized);
    return normalized;
  }

  function getOpportunity(id){
    return getOpportunities().find(o=>String(o.id)===String(id)) || null;
  }

  function setCurrentOpportunity(o){
    if(!o){ localStorage.removeItem(KEYS.CURRENT); return null; }
    const value = normalize(o);
    write(KEYS.CURRENT,value);
    return value;
  }

  function getCurrentOpportunity(){ return normalize(read(KEYS.CURRENT,null)); }

  function log(type,description,meta){
    const list = read(KEYS.ACTIVITY,[]);
    list.unshift({id:uid('act'),type,description,meta:meta||{},createdAt:now()});
    write(KEYS.ACTIVITY,list.slice(0,500));
  }

  function upsertOpportunity(data){
    const list = getOpportunities();
    const incoming = normalize(data);
    const index = list.findIndex(o=>String(o.id)===String(incoming.id));
    let saved;
    if(index>=0){
      const previous=list[index];
      saved=normalize({
        ...previous,
        ...incoming,
        id:previous.id,
        createdAt:previous.createdAt,
        analysis:incoming.analysis ?? previous.analysis,
        quote:incoming.quote ?? previous.quote,
        finalProposal:incoming.finalProposal ?? previous.finalProposal,
        updatedAt:now()
      });
      list[index]=saved;
    }else{
      saved=normalize({...incoming,createdAt:incoming.createdAt||now(),updatedAt:now()});
      list.unshift(saved);
    }
    saveOpportunities(list);
    setCurrentOpportunity(saved);
    log(index>=0?'opportunity.updated':'opportunity.created',saved.project||saved.client,{opportunityId:saved.id});
    return saved;
  }

  function updateOpportunity(id,patch){
    const current=getOpportunity(id);
    if(!current) return null;
    return upsertOpportunity({...current,...patch,id:current.id});
  }

  function createOpportunity(data){ return upsertOpportunity({...data,id:data?.id||uid('opp'),stage:data?.stage||'new'}); }

  function attachAnalysis(analysis,id){
    if(!analysis) return null;
    write(KEYS.ANALYSIS,analysis);
    let current=id?getOpportunity(id):getCurrentOpportunity();
    if(!current){
      current=createOpportunity({
        client:analysis.client||analysis.company||'',
        project:analysis.project||analysis.fileName||'Análisis de documento',
        origin:'document',stage:'analysis',analysis,
        sourceDocument:analysis.fileName||''
      });
    }
    const saved=updateOpportunity(current.id,{analysis,sourceDocument:analysis.fileName||current.sourceDocument,stage:current.stage==='new'?'analysis':current.stage});
    log('analysis.attached','Análisis asociado a oportunidad',{opportunityId:saved?.id});
    return saved;
  }

  function attachQuote(quote,id){
    const current=id?getOpportunity(id):getCurrentOpportunity();
    if(!current||!quote) return null;
    const saved=updateOpportunity(current.id,{quote,product:quote.product||current.product,productFolderId:quote.productFolderId||current.productFolderId,solution:quote.product||current.solution,stage:'quote',status:'quote'});
    log('quote.attached','Cotización guardada',{opportunityId:saved.id,product:quote.product||''});
    return saved;
  }

  function attachProposal(proposal,id){
    const current=id?getOpportunity(id):getCurrentOpportunity();
    if(!current||!proposal) return null;
    const saved=updateOpportunity(current.id,{finalProposal:proposal,stage:'proposal',status:'proposal'});
    log('proposal.attached','Propuesta final asociada',{opportunityId:saved.id});
    return saved;
  }

  function setStatus(id,status,extra){ return updateOpportunity(id,{...(extra||{}),stage:stageId(status),status:stageId(status)}); }

  function getAnalysis(){ return read(KEYS.ANALYSIS,null); }
  function setAnalysis(data){ return write(KEYS.ANALYSIS,data); }

  function upsertProspect(data){
    const list=read(KEYS.PROSPECTS,[]);
    const incoming={...data,id:data?.id||uid('pros'),createdAt:data?.createdAt||now(),updatedAt:now()};
    const index=list.findIndex(x=>String(x.id)===String(incoming.id));
    if(index>=0) list[index]={...list[index],...incoming}; else list.unshift(incoming);
    write(KEYS.PROSPECTS,list);
    return incoming;
  }
  function getProspects(){ const x=read(KEYS.PROSPECTS,[]); return Array.isArray(x)?x:[]; }

  function createFromMarket(data){
    const prospect=upsertProspect(data);
    const opp=createOpportunity({
      client:prospect.client||prospect.company||prospect.name||'',
      project:prospect.project||('Prospecto '+(prospect.client||prospect.name||'')),
      origin:'market',stage:'new',
      owner:prospect.owner||'',
      objective:prospect.objective||'',
      solution:prospect.solution||'',
      requirements:prospect.requirements||'',
      notes:prospect.notes||'',
      market:prospect
    });
    log('market.converted','Prospecto convertido en oportunidad',{prospectId:prospect.id,opportunityId:opp.id});
    return opp;
  }

  function recommendSolution(input){
    const text=JSON.stringify(input||{}).toLowerCase();
    const scores={
      'Perfil Digital':0,'Onboarding Addoc':0,'Firmas Addoc':0,'Visualizador Addoc':0,'Islas':0,'Thuban':0,'Captika':0,'Edatalia':0,'ADEA Doc':0,'Documenta Web':0
    };
    const rules=[
      ['Perfil Digital',['recibo','legajo','empleado','rrhh','recursos humanos'],4],
      ['Onboarding Addoc',['onboarding','alta','incorporacion','incorporación','legajo de ingreso'],4],
      ['Firmas Addoc',['firma electronica','firma electrónica','firmar','firmas'],3],
      ['Edatalia',['firma digital','firma remota','firma biometrica','firma biométrica'],3],
      ['Captika',['ocr','captura','reconocimiento','ingesta'],3],
      ['Thuban',['workflow','flujo','expediente','gestor documental','metadato','alerta','versionado'],4],
      ['Visualizador Addoc',['visualizar','consulta documental','buscar documentos','consulta'],2],
      ['Islas',['multicliente','nuevo visualizador','ingesta','consulta documental'],3],
      ['ADEA Doc',['cajas','archivo','documentacion','documentación'],2],
      ['Documenta Web',['documenta web','migracion desde documenta'],3]
    ];
    rules.forEach(([product,terms,weight])=>terms.forEach(t=>{if(text.includes(t)) scores[product]+=weight;}));
    return Object.entries(scores).sort((a,b)=>b[1]-a[1]).filter(x=>x[1]>0).slice(0,3).map(x=>({product:x[0],score:x[1]}));
  }

  function context(){
    const opportunity=getCurrentOpportunity();
    return {opportunity,analysis:opportunity?.analysis||getAnalysis(),quote:opportunity?.quote||null,proposal:opportunity?.finalProposal||null,prospects:getProspects()};
  }

  function navigateToOpportunity(id,page){
    const o=getOpportunity(id);
    if(!o) return false;
    setCurrentOpportunity(o);
    if(o.analysis) setAnalysis(o.analysis);
    window.location.href=page||'oportunidades.html';
    return true;
  }

  function dashboard(){
    const opportunities=getOpportunities();
    return {
      total:opportunities.length,
      analysis:opportunities.filter(o=>o.stage==='analysis').length,
      quote:opportunities.filter(o=>o.stage==='quote').length,
      proposal:opportunities.filter(o=>o.stage==='proposal').length,
      won:opportunities.filter(o=>o.stage==='won').length,
      lost:opportunities.filter(o=>o.stage==='lost').length,
      prospects:getProspects().length,
      withAnalysis:opportunities.filter(o=>o.analysis).length,
      withQuote:opportunities.filter(o=>o.quote).length,
      withProposal:opportunities.filter(o=>o.finalProposal).length
    };
  }

  window.PreventaCore={
    keys:KEYS, stages:STAGES,
    read,write,uid,now,stageId,normalize,
    getOpportunities,saveOpportunities,getOpportunity,setCurrentOpportunity,getCurrentOpportunity,
    upsertOpportunity,updateOpportunity,createOpportunity,attachAnalysis,attachQuote,attachProposal,setStatus,
    getAnalysis,setAnalysis,upsertProspect,getProspects,createFromMarket,recommendSolution,context,navigateToOpportunity,dashboard,log
  };
})();
